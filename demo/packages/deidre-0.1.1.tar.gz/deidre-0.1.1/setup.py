from setuptools import setup, find_packages

setup(
    name='deidre',
    version='0.1.1',
    description="Deidre: a lightweight scheduler.",
    long_description=open('readme.md').read(),
    url='https://github.com/vogt4nick/deidre',
    author='Nick Vogt',
    author_email='vogt4nick@gmail.com',
    license='MIT',
    packages=["deidre"],
    # install_requires='',
    test_suite='nose.collector',
    tests_require=['nose']
)
