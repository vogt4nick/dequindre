
```deidre-logo
      _      _     _
     | |    (_)   | |
   __| | ___ _  __| |_ __ ___
  / _` |/ _ \ |/ _` | '__/ _ \
 | (_| |  __/ | (_| | | |  __/
  \__,_|\___|_|\__,_|_|  \___|
```

Deidre (_DEE-drah_) is a lightweight scheduler for simple workflows and data pipelines. Deidre has no python dependencies, leverages conda environments, and is designed to be functional on Windows, Mac OS X, and Linux machines.
