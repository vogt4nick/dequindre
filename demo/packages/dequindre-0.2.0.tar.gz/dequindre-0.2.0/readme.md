
```dequindre-logo
     _                  _           _
  __| | ___  __ _ _   _(_)_ __   __| |_ __ ___
 / _` |/ _ \/ _` | | | | | '_ \ / _` | '__/ _ \
| (_| |  __/ (_| | |_| | | | | | (_| | | |  __/
 \__,_|\___|\__, |\__,_|_|_| |_|\__,_|_|  \___|
               |_|
```

Dequindre (_deh-KWIN-der_) is a minimalist scheduler for workflow automation. Dequindre makes it easy to configure, test, and deploy POC data pipelines. It also functions as a learning tool for students and professionals without the time or resources to setup the requisite architecture for a production data pipeline.  
